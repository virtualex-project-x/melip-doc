package com.melip.webservices.entity.common;

/**
 * エンティティの基底インタフェースです。
 */
public interface IEntity {

}
