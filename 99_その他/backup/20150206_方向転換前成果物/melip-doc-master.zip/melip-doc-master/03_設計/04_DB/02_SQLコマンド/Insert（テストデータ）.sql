-- �R�[�h�O���[�v�iinsert���j
insert into M_CD_GRP values (1, now(), 1, now(), 1, 0, 'Sts', '�X�e�[�^�X', '');
insert into M_CD_GRP values (2, now(), 1, now(), 1, 0, 'LangDiv', '����敪', '');
insert into M_CD_GRP values (3, now(), 1, now(), 1, 0, 'LayoutType', '���C�A�E�g���', '');
insert into M_CD_GRP values (4, now(), 1, now(), 1, 0, 'AttGrpType', '�����O���[�v���', '');
insert into M_CD_GRP values (5, now(), 1, now(), 1, 0, 'PublishSts', '���J�X�e�[�^�X', '');
insert into M_CD_GRP values (6, now(), 1, now(), 1, 0, 'HasNotHave', '�L��', '');
insert into M_CD_GRP values (7, now(), 1, now(), 1, 0, 'LayoutObjType', '���C�A�E�g�I�u�W�F�N�g�^�C�v', '');
insert into M_CD_GRP values (8, now(), 1, now(), 1, 0, 'LayoutMultiplicity', '���C�A�E�g���d�x', '');
insert into M_CD_GRP values (9, now(), 1, now(), 1, 0, 'Entity', '�G���e�B�e�B', '');
insert into M_CD_GRP values (10, now(), 1, now(), 1, 0, 'FacilityType', '�{�ݎ��', '');

-- �R�[�h�iinsert���j
insert into M_CD_VAL values (1, now(), 1, now(), 1, 0, '1', 'val', 'Valid', 1);
insert into M_CD_VAL values (2, now(), 1, now(), 1, 0, '1', 'inval', 'Invalid', 2);
insert into M_CD_VAL values (3, now(), 1, now(), 1, 0, '1', 'del', 'Deleted', 3);
insert into M_CD_VAL values (4, now(), 1, now(), 1, 0, '2', 'common', 'Common', 1);
insert into M_CD_VAL values (5, now(), 1, now(), 1, 0, '2', 'ja', 'Japanese', 2);
insert into M_CD_VAL values (6, now(), 1, now(), 1, 0, '2', 'en', 'English', 3);
insert into M_CD_VAL values (7, now(), 1, now(), 1, 0, '3', 'men', 'Menu', 1);
insert into M_CD_VAL values (8, now(), 1, now(), 1, 0, '3', 'lst', 'List', 2);
insert into M_CD_VAL values (9, now(), 1, now(), 1, 0, '3', 'map', 'Map', 3);
insert into M_CD_VAL values (10, now(), 1, now(), 1, 0, '3', 'det', 'Detail', 4);
insert into M_CD_VAL values (11, now(), 1, now(), 1, 0, '4', 'txt', 'Text', 1);
insert into M_CD_VAL values (12, now(), 1, now(), 1, 0, '4', 'cd', 'Code', 2);
insert into M_CD_VAL values (13, now(), 1, now(), 1, 0, '4', 'imgp', 'ImagePath', 3);
insert into M_CD_VAL values (14, now(), 1, now(), 1, 0, '4', 'movp', 'MoviePath', 4);
insert into M_CD_VAL values (15, now(), 1, now(), 1, 0, '4', 'lon', 'Longitude', 5);
insert into M_CD_VAL values (16, now(), 1, now(), 1, 0, '4', 'lat', 'Latitude', 6);
insert into M_CD_VAL values (17, now(), 1, now(), 1, 0, '5', 'dcls', 'Disclose', 1);
insert into M_CD_VAL values (18, now(), 1, now(), 1, 0, '5', 'cls', 'Close', 2);
insert into M_CD_VAL values (19, now(), 1, now(), 1, 0, '6', 'has', 'Has', 1);
insert into M_CD_VAL values (20, now(), 1, now(), 1, 0, '6', 'nohas', 'DoesNotHave', 2);
insert into M_CD_VAL values (21, now(), 1, now(), 1, 0, '7', 'txt', 'Text', 1);
insert into M_CD_VAL values (22, now(), 1, now(), 1, 0, '7', 'img', 'Image', 2);
insert into M_CD_VAL values (23, now(), 1, now(), 1, 0, '7', 'mov', 'Movie', 3);
insert into M_CD_VAL values (24, now(), 1, now(), 1, 0, '7', 'map', 'Map', 4);
insert into M_CD_VAL values (25, now(), 1, now(), 1, 0, '7', 'button', 'Button', 5);
insert into M_CD_VAL values (26, now(), 1, now(), 1, 0, '8', 'sin', 'Single', 1);
insert into M_CD_VAL values (27, now(), 1, now(), 1, 0, '8', 'multi', 'Multiple', 2);
insert into M_CD_VAL values (28, now(), 1, now(), 1, 0, '9', 'reg', 'Region', 1);
insert into M_CD_VAL values (29, now(), 1, now(), 1, 0, '9', 'fac', 'Facility', 2);
insert into M_CD_VAL values (30, now(), 1, now(), 1, 0, '9', 'facgrp', 'FacilityGroup', 3);
insert into M_CD_VAL values (31, now(), 1, now(), 1, 0, '9', 'facgrpln', 'FacilityFacilityGroupLink', 4);
insert into M_CD_VAL values (32, now(), 1, now(), 1, 0, '10', 'shp', 'Shop', 1);
insert into M_CD_VAL values (33, now(), 1, now(), 1, 0, '10', 'res', 'Restaurant', 2);

-- �R�[�h������iinsert���j
insert into M_CD_VAL_LANG values (1, now(), 1, now(), 1, 0, '1', 'ja', '�L��');
insert into M_CD_VAL_LANG values (2, now(), 1, now(), 1, 0, '1', 'en', 'Valid');
insert into M_CD_VAL_LANG values (3, now(), 1, now(), 1, 0, '2', 'ja', '����');
insert into M_CD_VAL_LANG values (4, now(), 1, now(), 1, 0, '2', 'en', 'Invalid');
insert into M_CD_VAL_LANG values (5, now(), 1, now(), 1, 0, '3', 'ja', '�폜');
insert into M_CD_VAL_LANG values (6, now(), 1, now(), 1, 0, '3', 'en', 'Deleted');
insert into M_CD_VAL_LANG values (7, now(), 1, now(), 1, 0, '4', 'ja', '����');
insert into M_CD_VAL_LANG values (8, now(), 1, now(), 1, 0, '4', 'en', 'Common');
insert into M_CD_VAL_LANG values (9, now(), 1, now(), 1, 0, '5', 'ja', '���{��');
insert into M_CD_VAL_LANG values (10, now(), 1, now(), 1, 0, '5', 'en', 'Japanese');
insert into M_CD_VAL_LANG values (11, now(), 1, now(), 1, 0, '6', 'ja', '�p��');
insert into M_CD_VAL_LANG values (12, now(), 1, now(), 1, 0, '6', 'en', 'English');
insert into M_CD_VAL_LANG values (13, now(), 1, now(), 1, 0, '7', 'ja', '���j���[');
insert into M_CD_VAL_LANG values (14, now(), 1, now(), 1, 0, '8', 'ja', '�ꗗ');
insert into M_CD_VAL_LANG values (15, now(), 1, now(), 1, 0, '9', 'ja', '�n�}');
insert into M_CD_VAL_LANG values (16, now(), 1, now(), 1, 0, '10', 'ja', '�ڍ�');
insert into M_CD_VAL_LANG values (17, now(), 1, now(), 1, 0, '11', 'ja', '�e�L�X�g');
insert into M_CD_VAL_LANG values (18, now(), 1, now(), 1, 0, '12', 'ja', '�R�[�h');
insert into M_CD_VAL_LANG values (19, now(), 1, now(), 1, 0, '13', 'ja', '�摜�p�X');
insert into M_CD_VAL_LANG values (20, now(), 1, now(), 1, 0, '14', 'ja', '����p�X');
insert into M_CD_VAL_LANG values (21, now(), 1, now(), 1, 0, '15', 'ja', '�ܓx');
insert into M_CD_VAL_LANG values (22, now(), 1, now(), 1, 0, '16', 'ja', '�o�x');
insert into M_CD_VAL_LANG values (23, now(), 1, now(), 1, 0, '17', 'ja', '���J');
insert into M_CD_VAL_LANG values (24, now(), 1, now(), 1, 0, '18', 'ja', '����J');
insert into M_CD_VAL_LANG values (25, now(), 1, now(), 1, 0, '19', 'ja', '�L��');
insert into M_CD_VAL_LANG values (26, now(), 1, now(), 1, 0, '19', 'us', 'Has');
insert into M_CD_VAL_LANG values (27, now(), 1, now(), 1, 0, '20', 'ja', '����');
insert into M_CD_VAL_LANG values (28, now(), 1, now(), 1, 0, '20', 'us', 'Does not have');
insert into M_CD_VAL_LANG values (29, now(), 1, now(), 1, 0, '21', 'ja', '�e�L�X�g');
insert into M_CD_VAL_LANG values (30, now(), 1, now(), 1, 0, '22', 'ja', '�摜');
insert into M_CD_VAL_LANG values (31, now(), 1, now(), 1, 0, '23', 'ja', '����');
insert into M_CD_VAL_LANG values (32, now(), 1, now(), 1, 0, '24', 'ja', '�n�}');
insert into M_CD_VAL_LANG values (33, now(), 1, now(), 1, 0, '25', 'ja', '�{�^��');
insert into M_CD_VAL_LANG values (34, now(), 1, now(), 1, 0, '26', 'ja', '�V���O��');
insert into M_CD_VAL_LANG values (35, now(), 1, now(), 1, 0, '27', 'ja', '�}���`');
insert into M_CD_VAL_LANG values (36, now(), 1, now(), 1, 0, '28', 'ja', '�n��');
insert into M_CD_VAL_LANG values (37, now(), 1, now(), 1, 0, '29', 'ja', '�{��');
insert into M_CD_VAL_LANG values (38, now(), 1, now(), 1, 0, '30', 'ja', '�{�݃O���[�v');
insert into M_CD_VAL_LANG values (39, now(), 1, now(), 1, 0, '31', 'ja', '�{��_�{�݃O���[�v_�����N');
insert into M_CD_VAL_LANG values (40, now(), 1, now(), 1, 0, '32', 'ja', '�X');
insert into M_CD_VAL_LANG values (41, now(), 1, now(), 1, 0, '32', 'en', 'Shop');
insert into M_CD_VAL_LANG values (42, now(), 1, now(), 1, 0, '33', 'ja', '���X�g����');
insert into M_CD_VAL_LANG values (43, now(), 1, now(), 1, 0, '33', 'en', 'Restaurant');

-- �{�݁iinsert���j
insert into M_FACILITY values (1, now(), 1, now(), 1, 'val', 1, 'dcls');
insert into M_FACILITY values (2, now(), 1, now(), 1, 'val', 1, 'dcls');
insert into M_FACILITY values (3, now(), 1, now(), 1, 'val', 2, 'dcls');
insert into M_FACILITY values (4, now(), 1, now(), 1, 'val', 2, 'dcls');

-- �{�ݑ����O���[�v�iinsert���j
insert into M_FACILITY_ATTR_GRP values (1, now(), 1, now(), 1, 'val', 'txt', null);
insert into M_FACILITY_ATTR_GRP values (2, now(), 1, now(), 1, 'val', 'txt', null);
insert into M_FACILITY_ATTR_GRP values (3, now(), 1, now(), 1, 'val', 'imgp', null);
insert into M_FACILITY_ATTR_GRP values (4, now(), 1, now(), 1, 'val', 'cd', 10);

-- �{�ݑ����O���[�v_������iinsert���j
insert into M_FACILITY_ATTR_GRP_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '����');
insert into M_FACILITY_ATTR_GRP_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Name');
insert into M_FACILITY_ATTR_GRP_LANG values (3, now(), 1, now(), 1, 'val', 2, 'ja', '������');
insert into M_FACILITY_ATTR_GRP_LANG values (4, now(), 1, now(), 1, 'val', 2, 'en', 'Description');
insert into M_FACILITY_ATTR_GRP_LANG values (5, now(), 1, now(), 1, 'val', 3, 'ja', '�摜1');
insert into M_FACILITY_ATTR_GRP_LANG values (6, now(), 1, now(), 1, 'val', 3, 'en', 'Image 1');
insert into M_FACILITY_ATTR_GRP_LANG values (7, now(), 1, now(), 1, 'val', 4, 'ja', '�{�ݎ��');
insert into M_FACILITY_ATTR_GRP_LANG values (8, now(), 1, now(), 1, 'val', 4, 'en', 'Facility Type');

-- �{�ݑ����l�iinsert���j
insert into M_FACILITY_ATTR_VAL values (1, now(), 1, now(), 1, 'val', 1, 1);
insert into M_FACILITY_ATTR_VAL values (2, now(), 1, now(), 1, 'val', 1, 2);
insert into M_FACILITY_ATTR_VAL values (3, now(), 1, now(), 1, 'val', 1, 3);
insert into M_FACILITY_ATTR_VAL values (4, now(), 1, now(), 1, 'val', 2, 1);
insert into M_FACILITY_ATTR_VAL values (5, now(), 1, now(), 1, 'val', 2, 2);
insert into M_FACILITY_ATTR_VAL values (6, now(), 1, now(), 1, 'val', 2, 3);
insert into M_FACILITY_ATTR_VAL values (7, now(), 1, now(), 1, 'val', 3, 1);
insert into M_FACILITY_ATTR_VAL values (8, now(), 1, now(), 1, 'val', 3, 2);
insert into M_FACILITY_ATTR_VAL values (9, now(), 1, now(), 1, 'val', 3, 3);
insert into M_FACILITY_ATTR_VAL values (10, now(), 1, now(), 1, 'val', 4, 1);
insert into M_FACILITY_ATTR_VAL values (11, now(), 1, now(), 1, 'val', 4, 2);
insert into M_FACILITY_ATTR_VAL values (12, now(), 1, now(), 1, 'val', 4, 3);
insert into M_FACILITY_ATTR_VAL values (13, now(), 1, now(), 1, 'val', 3, 4);
insert into M_FACILITY_ATTR_VAL values (14, now(), 1, now(), 1, 'val', 4, 4);

-- �{�ݑ����l_������iinsert���j
insert into M_FACILITY_ATTR_VAL_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '�������Ƌ{');
insert into M_FACILITY_ATTR_VAL_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Nikko Toshogu');
insert into M_FACILITY_ATTR_VAL_LANG values (3, now(), 1, now(), 1, 'val', 2, 'ja', '�������Ƌ{�̎{�ݐ�����');
insert into M_FACILITY_ATTR_VAL_LANG values (4, now(), 1, now(), 1, 'val', 2, 'en', 'Nikko Toshogus description');
insert into M_FACILITY_ATTR_VAL_LANG values (5, now(), 1, now(), 1, 'val', 3, 'ja', 'img/nikko/image1_ja.png');
insert into M_FACILITY_ATTR_VAL_LANG values (6, now(), 1, now(), 1, 'val', 3, 'en', 'img/nikko/image1_en.png');
insert into M_FACILITY_ATTR_VAL_LANG values (7, now(), 1, now(), 1, 'val', 4, 'ja', '�،��̑�');
insert into M_FACILITY_ATTR_VAL_LANG values (8, now(), 1, now(), 1, 'val', 4, 'en', 'Kegon Waterfall');
insert into M_FACILITY_ATTR_VAL_LANG values (9, now(), 1, now(), 1, 'val', 5, 'ja', '�،��̑�̎{�ݐ�����');
insert into M_FACILITY_ATTR_VAL_LANG values (10, now(), 1, now(), 1, 'val', 5, 'en', 'Kegon Waterfalls description');
insert into M_FACILITY_ATTR_VAL_LANG values (11, now(), 1, now(), 1, 'val', 6, 'ja', 'img/kegon/image1_ja.png');
insert into M_FACILITY_ATTR_VAL_LANG values (12, now(), 1, now(), 1, 'val', 6, 'en', 'img/kegon/image1_en.png');
insert into M_FACILITY_ATTR_VAL_LANG values (13, now(), 1, now(), 1, 'val', 7, 'ja', '���̉w�@�x�m�g�c');
insert into M_FACILITY_ATTR_VAL_LANG values (14, now(), 1, now(), 1, 'val', 7, 'en', 'Fuji Yoshida Road Station');
insert into M_FACILITY_ATTR_VAL_LANG values (15, now(), 1, now(), 1, 'val', 8, 'ja', '���̉w�@�x�m�g�c�̎{�ݐ�����');
insert into M_FACILITY_ATTR_VAL_LANG values (16, now(), 1, now(), 1, 'val', 8, 'en', 'Fuji Yoshida Road Stationss description');
insert into M_FACILITY_ATTR_VAL_LANG values (17, now(), 1, now(), 1, 'val', 9, 'ja', 'img/fujiYoshida/image1_jp.png');
insert into M_FACILITY_ATTR_VAL_LANG values (18, now(), 1, now(), 1, 'val', 9, 'en', 'img/fujiYoshida/image1_en.png');
insert into M_FACILITY_ATTR_VAL_LANG values (19, now(), 1, now(), 1, 'val', 10, 'ja', '�x�m�g�c�s��g�c�E���j����������');
insert into M_FACILITY_ATTR_VAL_LANG values (20, now(), 1, now(), 1, 'val', 10, 'en', 'Fuji Yoshida Hisotical Museum');
insert into M_FACILITY_ATTR_VAL_LANG values (21, now(), 1, now(), 1, 'val', 11, 'ja', '�x�m�g�c�s��g�c�E���j���������ق̎{�ݐ�����');
insert into M_FACILITY_ATTR_VAL_LANG values (22, now(), 1, now(), 1, 'val', 11, 'en', 'Fuji Yoshida Hisotical Museums description');
insert into M_FACILITY_ATTR_VAL_LANG values (23, now(), 1, now(), 1, 'val', 12, 'common', 'img/fujiYoshidaHistoricalMuseum/image_1_common.png');
insert into M_FACILITY_ATTR_VAL_LANG values (24, now(), 1, now(), 1, 'val', 13, 'common', 'shp');
insert into M_FACILITY_ATTR_VAL_LANG values (25, now(), 1, now(), 1, 'val', 14, 'common', 'res');

-- �{��_�{�݃O���[�v_�����N�iinsert���j
insert into M_FACILITY_FACILITY_GRP_LINK values (1, now(), 1, now(), 1, 'val', 1, 1);
insert into M_FACILITY_FACILITY_GRP_LINK values (2, now(), 1, now(), 1, 'val', 2, 1);
insert into M_FACILITY_FACILITY_GRP_LINK values (3, now(), 1, now(), 1, 'val', 3, 2);
insert into M_FACILITY_FACILITY_GRP_LINK values (4, now(), 1, now(), 1, 'val', 4, 2);

-- �{��_�{�݃O���[�v�����N�����O���[�v�iinsert���j
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_GRP values (1, now(), 1, now(), 1, 'val', 'txt', null);

-- �{��_�{�݃O���[�v�����N�����O���[�v_������iinsert���j
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_GRP_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '�⑫��');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_GRP_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Additional Info');

-- �{��_�{�݃O���[�v�����N�����l�iinsert���j
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL values (1, now(), 1, now(), 1, 'val', 1, 1);
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL values (2, now(), 1, now(), 1, 'val', 2, 1);
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL values (3, now(), 1, now(), 1, 'val', 3, 1);
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL values (4, now(), 1, now(), 1, 'val', 4, 1);

-- �{��_�{�݃O���[�v�����N�����l_������iinsert���j
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '�����̎{�݃O���[�v�E�������Ƌ{�̕⑫��');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Toshogu in Nikko Faciligy Group (Additional Info)');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (3, now(), 1, now(), 1, 'val', 2, 'ja', '�����̎{�݃O���[�v�E�،��̑�̕⑫��');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (4, now(), 1, now(), 1, 'val', 2, 'en', 'Kegon Waterfall in Nikko Faciligy Group (Additional Info)');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (5, now(), 1, now(), 1, 'val', 3, 'ja', '�x�m�܌΂̎{�݃O���[�v�E���̉w�@�x�m�g�c�̕⑫��');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (6, now(), 1, now(), 1, 'val', 3, 'en', 'Road Station in Fuji Goko Group (Additional Info)');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (7, now(), 1, now(), 1, 'val', 4, 'ja', '�x�m�܌΂̎{�݃O���[�v�E�x�m�g�c�s��g�c�E���j���������ق̕⑫��');
insert into M_FACILITY_FACILITY_GRP_LINK_ATTR_VAL_LANG values (8, now(), 1, now(), 1, 'val', 4, 'en', 'History Museum in Fuji Goko Group (Additional Info)');

-- �{�݃O���[�v�iinsert���j
insert into M_FACILITY_GRP values (1, now(), 1, now(), 1, 'val', 1, 'dcls');
insert into M_FACILITY_GRP values (2, now(), 1, now(), 1, 'val', 2, 'dcls');

-- �{�݃O���[�v�����O���[�v�iinsert���j
insert into M_FACILITY_GRP_ATTR_GRP values (1, now(), 1, now(), 1, 'val', 'txt', null);
insert into M_FACILITY_GRP_ATTR_GRP values (2, now(), 1, now(), 1, 'val', 'txt', null);

-- �{�݃O���[�v�����O���[�v_������iinsert���j
insert into M_FACILITY_GRP_ATTR_GRP_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '����');
insert into M_FACILITY_GRP_ATTR_GRP_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Name');
insert into M_FACILITY_GRP_ATTR_GRP_LANG values (3, now(), 1, now(), 1, 'val', 2, 'ja', '������');
insert into M_FACILITY_GRP_ATTR_GRP_LANG values (4, now(), 1, now(), 1, 'val', 2, 'en', 'Description');

-- �{�݃O���[�v�����l�iinsert���j
insert into M_FACILITY_GRP_ATTR_VAL values (1, now(), 1, now(), 1, 'val', 1, 1);
insert into M_FACILITY_GRP_ATTR_VAL values (2, now(), 1, now(), 1, 'val', 1, 2);
insert into M_FACILITY_GRP_ATTR_VAL values (3, now(), 1, now(), 1, 'val', 2, 1);
insert into M_FACILITY_GRP_ATTR_VAL values (4, now(), 1, now(), 1, 'val', 2, 2);

-- �{�݃O���[�v�����l_������iinsert���j
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '�������Ƌ{�̎{�݃O���[�v');
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Nikko Toshogus Group');
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (3, now(), 1, now(), 1, 'val', 2, 'ja', '�������Ƌ{�̎{�݃O���[�v������');
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (4, now(), 1, now(), 1, 'val', 2, 'en', 'Nikko Toshogus Group description');
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (5, now(), 1, now(), 1, 'val', 3, 'ja', '�x�m�܌΂̎{�݃O���[�v');
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (6, now(), 1, now(), 1, 'val', 3, 'en', 'Fuji Gokos Group');
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (7, now(), 1, now(), 1, 'val', 4, 'ja', '�x�m�܌΂̎{�݃O���[�v������');
insert into M_FACILITY_GRP_ATTR_VAL_LANG values (8, now(), 1, now(), 1, 'val', 4, 'en', 'Fuji Gokos Group description');

-- ���C�A�E�g�iinsert���j
insert into M_LAYOUT values (1, now(), 1, now(), 1, 'val', 'Menu001', '���j���[001', 'men');
insert into M_LAYOUT values (2, now(), 1, now(), 1, 'val', 'Menu002', '���j���[002', 'men');
insert into M_LAYOUT values (3, now(), 1, now(), 1, 'val', 'List001', '�ꗗ001', 'lst');
insert into M_LAYOUT values (4, now(), 1, now(), 1, 'val', 'List002', '�ꗗ002', 'lst');
insert into M_LAYOUT values (5, now(), 1, now(), 1, 'val', 'Detail001', '�ڍ�001', 'det');
insert into M_LAYOUT values (6, now(), 1, now(), 1, 'val', 'Detail002', '�ڍ�002', 'det');

-- ���C�A�E�g�I�u�W�F�N�g�iinsert���j
insert into M_LAYOUT_OBJ values (1, now(), 1, now(), 1, 'val', 1, 'TopImg', '�g�b�v�摜','img');
insert into M_LAYOUT_OBJ values (2, now(), 1, now(), 1, 'val', 1, 'MenuBtn01', '���j���[�{�^��1','button');
insert into M_LAYOUT_OBJ values (3, now(), 1, now(), 1, 'val', 1, 'MenuBtn02', '���j���[�{�^��2','button');
insert into M_LAYOUT_OBJ values (4, now(), 1, now(), 1, 'val', 1, 'MenuBtn03', '���j���[�{�^��3','button');
insert into M_LAYOUT_OBJ values (5, now(), 1, now(), 1, 'val', 2, 'TopImg', '�g�b�v�摜','img');
insert into M_LAYOUT_OBJ values (6, now(), 1, now(), 1, 'val', 2, 'MenuBtn01', '���j���[�{�^��1','button');
insert into M_LAYOUT_OBJ values (7, now(), 1, now(), 1, 'val', 2, 'MenuBtn02', '���j���[�{�^��2','button');
insert into M_LAYOUT_OBJ values (8, now(), 1, now(), 1, 'val', 2, 'MenuBtn03', '���j���[�{�^��3','button');
insert into M_LAYOUT_OBJ values (9, now(), 1, now(), 1, 'val', 3, 'PntDscp', '�e������','txt');
insert into M_LAYOUT_OBJ values (10, now(), 1, now(), 1, 'val', 4, 'DscpImg', '�����摜','img');
insert into M_LAYOUT_OBJ values (11, now(), 1, now(), 1, 'val', 4, 'Dsc', '������','txt');
insert into M_LAYOUT_OBJ values (12, now(), 1, now(), 1, 'val', 5, 'PntDscp', '�e������','txt');
insert into M_LAYOUT_OBJ values (13, now(), 1, now(), 1, 'val', 6, 'DscpImg', '�����摜','img');
insert into M_LAYOUT_OBJ values (14, now(), 1, now(), 1, 'val', 6, 'Dsc', '������','list');
insert into M_LAYOUT_OBJ values (15, now(), 1, now(), 1, 'val', 7, 'Img01', '�摜01','img');
insert into M_LAYOUT_OBJ values (16, now(), 1, now(), 1, 'val', 7, 'MainDscp', '�������i���C���j','txt');
insert into M_LAYOUT_OBJ values (17, now(), 1, now(), 1, 'val', 7, 'SubDscp', '�������i�⑫�j','txt');
insert into M_LAYOUT_OBJ values (18, now(), 1, now(), 1, 'val', 8, 'Img01', '�摜01','img');
insert into M_LAYOUT_OBJ values (19, now(), 1, now(), 1, 'val', 8, 'MainDscp', '�������i���C���j','txt');
insert into M_LAYOUT_OBJ values (20, now(), 1, now(), 1, 'val', 8, 'SubDscp', '�������i�⑫�j','list');

-- ���C�A�E�g�I�u�W�F�N�g�O���[�v�iinsert���j
insert into M_LAYOUT_OBJ_GRP values (1, now(), 1, now(), 1, 'val', 1, 'MainGrp', 'sin');
insert into M_LAYOUT_OBJ_GRP values (2, now(), 1, now(), 1, 'val', 2, 'MainGrp', 'sin');
insert into M_LAYOUT_OBJ_GRP values (3, now(), 1, now(), 1, 'val', 3, 'MainGrp', 'sin');
insert into M_LAYOUT_OBJ_GRP values (4, now(), 1, now(), 1, 'val', 3, 'ListGrp', 'multi');
insert into M_LAYOUT_OBJ_GRP values (5, now(), 1, now(), 1, 'val', 4, 'MainGrp', 'sin');
insert into M_LAYOUT_OBJ_GRP values (6, now(), 1, now(), 1, 'val', 4, 'ListGrp', 'multi');
insert into M_LAYOUT_OBJ_GRP values (7, now(), 1, now(), 1, 'val', 5, 'MainGrp', 'sin');
insert into M_LAYOUT_OBJ_GRP values (8, now(), 1, now(), 1, 'val', 6, 'MainGrp', 'sin');

-- �n��iinsert���j
insert into M_REGION values (1, now(), 1, now(), 1, 'val', 1, 'dcls');
insert into M_REGION values (2, now(), 1, now(), 1, 'val', 1, 'dcls');

-- �n�摮���O���[�v�iinsert���j
insert into M_REGION_ATTR_GRP values (1, now(), 1, now(), 1, 'val', 'txt', null);
insert into M_REGION_ATTR_GRP values (2, now(), 1, now(), 1, 'val', 'txt', null);
insert into M_REGION_ATTR_GRP values (3, now(), 1, now(), 1, 'val', 'cd', 6);
insert into M_REGION_ATTR_GRP values (4, now(), 1, now(), 1, 'val', 'imgp', null);

-- �n�摮���O���[�v_������iinsert���j
insert into M_REGION_ATTR_GRP_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '�n�於');
insert into M_REGION_ATTR_GRP_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Region Name');
insert into M_REGION_ATTR_GRP_LANG values (3, now(), 1, now(), 1, 'val', 2, 'ja', '������');
insert into M_REGION_ATTR_GRP_LANG values (4, now(), 1, now(), 1, 'val', 2, 'en', 'Description');
insert into M_REGION_ATTR_GRP_LANG values (5, now(), 1, now(), 1, 'val', 3, 'ja', '��`�L��');
insert into M_REGION_ATTR_GRP_LANG values (6, now(), 1, now(), 1, 'val', 3, 'en', 'Has Airport');
insert into M_REGION_ATTR_GRP_LANG values (7, now(), 1, now(), 1, 'val', 4, 'ja', '�摜1');
insert into M_REGION_ATTR_GRP_LANG values (8, now(), 1, now(), 1, 'val', 4, 'en', 'Image1');

-- �n�摮���l�iinsert���j
insert into M_REGION_ATTR_VAL values (1, now(), 1, now(), 1, 'val', 1, 1);
insert into M_REGION_ATTR_VAL values (2, now(), 1, now(), 1, 'val', 1, 2);
insert into M_REGION_ATTR_VAL values (3, now(), 1, now(), 1, 'val', 1, 3);
insert into M_REGION_ATTR_VAL values (4, now(), 1, now(), 1, 'val', 1, 4);
insert into M_REGION_ATTR_VAL values (5, now(), 1, now(), 1, 'val', 2, 1);
insert into M_REGION_ATTR_VAL values (6, now(), 1, now(), 1, 'val', 2, 2);
insert into M_REGION_ATTR_VAL values (7, now(), 1, now(), 1, 'val', 2, 3);
insert into M_REGION_ATTR_VAL values (8, now(), 1, now(), 1, 'val', 2, 4);

-- �n�摮���l_������iinsert���j
insert into M_REGION_ATTR_VAL_LANG values (1, now(), 1, now(), 1, 'val', 1, 'ja', '����');
insert into M_REGION_ATTR_VAL_LANG values (2, now(), 1, now(), 1, 'val', 1, 'en', 'Nikko');
insert into M_REGION_ATTR_VAL_LANG values (3, now(), 1, now(), 1, 'val', 2, 'ja', '�����̐�����');
insert into M_REGION_ATTR_VAL_LANG values (4, now(), 1, now(), 1, 'val', 2, 'en', 'Nikkos description');
insert into M_REGION_ATTR_VAL_LANG values (5, now(), 1, now(), 1, 'val', 3, 'common', 'has');
insert into M_REGION_ATTR_VAL_LANG values (6, now(), 1, now(), 1, 'val', 4, 'common', 'img/nikko/image1.png');
insert into M_REGION_ATTR_VAL_LANG values (7, now(), 1, now(), 1, 'val', 5, 'ja', '�x�m�܌�');
insert into M_REGION_ATTR_VAL_LANG values (8, now(), 1, now(), 1, 'val', 5, 'en', 'Fuji Goko');
insert into M_REGION_ATTR_VAL_LANG values (9, now(), 1, now(), 1, 'val', 6, 'ja', '�x�m�܌΂̐�����');
insert into M_REGION_ATTR_VAL_LANG values (10, now(), 1, now(), 1, 'val', 6, 'en', 'Fuji Gokos description');
insert into M_REGION_ATTR_VAL_LANG values (11, now(), 1, now(), 1, 'val', 7, 'common', 'nohas');
insert into M_REGION_ATTR_VAL_LANG values (12, now(), 1, now(), 1, 'val', 8, 'common', 'img/fujiGoko/image1.png');

-- �X�N���[���iinsert���j
insert into M_SCREEN values (1, now(), 1, now(), 1, 'val', 1, 1, 'reg', '�������j���[');
insert into M_SCREEN values (2, now(), 1, now(), 1, 'val', 1, 3, 'reg', '�����{�݈ꗗ');
insert into M_SCREEN values (3, now(), 1, now(), 1, 'val', 1, 5, 'fac', '�����{�ݏڍ�');
insert into M_SCREEN values (4, now(), 1, now(), 1, 'val', 2, 2, 'reg', '�x�m�܌΃��j���[');
insert into M_SCREEN values (5, now(), 1, now(), 1, 'val', 2, 4, 'reg', '�x�m�܌Ύ{�݈ꗗ');
insert into M_SCREEN values (6, now(), 1, now(), 1, 'val', 2, 6, 'fac', '�x�m�܌Ύ{�ݏڍ�');

-- �X�N���[���I�u�W�F�N�g�iinsert���j
insert into M_SCREEN_OBJ values (1, now(), 1, now(), 1, 'val', 1, 1);
insert into M_SCREEN_OBJ values (2, now(), 1, now(), 1, 'val', 1, 2);
insert into M_SCREEN_OBJ values (3, now(), 1, now(), 1, 'val', 1, 3);
insert into M_SCREEN_OBJ values (4, now(), 1, now(), 1, 'val', 1, 4);
insert into M_SCREEN_OBJ values (5, now(), 1, now(), 1, 'val', 2, 9);
insert into M_SCREEN_OBJ values (6, now(), 1, now(), 1, 'val', 3, 10);
insert into M_SCREEN_OBJ values (7, now(), 1, now(), 1, 'val', 3, 11);
insert into M_SCREEN_OBJ values (8, now(), 1, now(), 1, 'val', 4, 15);
insert into M_SCREEN_OBJ values (9, now(), 1, now(), 1, 'val', 4, 16);
insert into M_SCREEN_OBJ values (10, now(), 1, now(), 1, 'val', 4, 17);
insert into M_SCREEN_OBJ values (11, now(), 1, now(), 1, 'val', 5, 5);
insert into M_SCREEN_OBJ values (12, now(), 1, now(), 1, 'val', 5, 6);
insert into M_SCREEN_OBJ values (13, now(), 1, now(), 1, 'val', 5, 7);
insert into M_SCREEN_OBJ values (14, now(), 1, now(), 1, 'val', 5, 8);
insert into M_SCREEN_OBJ values (15, now(), 1, now(), 1, 'val', 6, 12);
insert into M_SCREEN_OBJ values (16, now(), 1, now(), 1, 'val', 7, 13);
insert into M_SCREEN_OBJ values (17, now(), 1, now(), 1, 'val', 7, 14);
insert into M_SCREEN_OBJ values (18, now(), 1, now(), 1, 'val', 8, 18);
insert into M_SCREEN_OBJ values (19, now(), 1, now(), 1, 'val', 8, 19);
insert into M_SCREEN_OBJ values (20, now(), 1, now(), 1, 'val', 8, 20);

-- �X�N���[���I�u�W�F�N�g�O���[�v�iinsert���j
insert into M_SCREEN_OBJ_GRP values (1, now(), 1, now(), 1, 'val', 1, 1, 'reg', null);
insert into M_SCREEN_OBJ_GRP values (2, now(), 1, now(), 1, 'val', 2, 3, 'reg', null);
insert into M_SCREEN_OBJ_GRP values (3, now(), 1, now(), 1, 'val', 2, 4, 'fac', null);
insert into M_SCREEN_OBJ_GRP values (4, now(), 1, now(), 1, 'val', 3, 7, 'fac', null);
insert into M_SCREEN_OBJ_GRP values (5, now(), 1, now(), 1, 'val', 4, 2, 'reg', null);
insert into M_SCREEN_OBJ_GRP values (6, now(), 1, now(), 1, 'val', 5, 5, 'reg', null);
insert into M_SCREEN_OBJ_GRP values (7, now(), 1, now(), 1, 'val', 5, 6, 'fac', 6);
insert into M_SCREEN_OBJ_GRP values (8, now(), 1, now(), 1, 'val', 6, 8, 'fac', null);

-- �X�N���[���I�u�W�F�N�g�����iinsert���j
insert into M_SCREEN_OBJ_ATTR values (1, now(), 1, now(), 1, 'val', 1, 'reg', 4, null, null);
insert into M_SCREEN_OBJ_ATTR values (2, now(), 1, now(), 1, 'val', 2, 'reg', 1, null, 2);
insert into M_SCREEN_OBJ_ATTR values (3, now(), 1, now(), 1, 'val', 3, 'reg', 1, null, 2);
insert into M_SCREEN_OBJ_ATTR values (4, now(), 1, now(), 1, 'val', 4, 'reg', 1, null, 2);
insert into M_SCREEN_OBJ_ATTR values (5, now(), 1, now(), 1, 'val', 5, 'reg', 2, null, null);
insert into M_SCREEN_OBJ_ATTR values (6, now(), 1, now(), 1, 'val', 6, 'fac', 3, null, 3);
insert into M_SCREEN_OBJ_ATTR values (7, now(), 1, now(), 1, 'val', 7, 'fac', 2, null, null);
insert into M_SCREEN_OBJ_ATTR values (8, now(), 1, now(), 1, 'val', 8, 'fac', 3, null, null);
insert into M_SCREEN_OBJ_ATTR values (9, now(), 1, now(), 1, 'val', 9, 'fac', 1, null, null);
insert into M_SCREEN_OBJ_ATTR values (10, now(), 1, now(), 1, 'val', 10, 'fac', 2, null, null);
insert into M_SCREEN_OBJ_ATTR values (11, now(), 1, now(), 1, 'val', 11, 'reg', 4, null, null);
insert into M_SCREEN_OBJ_ATTR values (12, now(), 1, now(), 1, 'val', 12, 'reg', 1, null, 5);
insert into M_SCREEN_OBJ_ATTR values (13, now(), 1, now(), 1, 'val', 13, 'reg', 1, null, 5);
insert into M_SCREEN_OBJ_ATTR values (14, now(), 1, now(), 1, 'val', 14, 'reg', 1, null, 5);
insert into M_SCREEN_OBJ_ATTR values (15, now(), 1, now(), 1, 'val', 15, 'reg', 2, null, null);
insert into M_SCREEN_OBJ_ATTR values (16, now(), 1, now(), 1, 'val', 16, 'fac', 3, null, null);
insert into M_SCREEN_OBJ_ATTR values (17, now(), 1, now(), 1, 'val', 17, 'fac', 1, 1, null);
insert into M_SCREEN_OBJ_ATTR values (18, now(), 1, now(), 1, 'val', 17, 'fac', 2, 2, null);
insert into M_SCREEN_OBJ_ATTR values (19, now(), 1, now(), 1, 'val', 18, 'fac', 3, null, null);
insert into M_SCREEN_OBJ_ATTR values (20, now(), 1, now(), 1, 'val', 19, 'fac', 1, null, null);
insert into M_SCREEN_OBJ_ATTR values (21, now(), 1, now(), 1, 'val', 20, 'fac', 1, 1, null);
insert into M_SCREEN_OBJ_ATTR values (22, now(), 1, now(), 1, 'val', 20, 'fac', 2, 2, null);

