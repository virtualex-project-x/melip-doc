package com.melip.webservices.service.common;

/**
 * サービスの基底インタフェースです。
 */
public interface IService {

}
