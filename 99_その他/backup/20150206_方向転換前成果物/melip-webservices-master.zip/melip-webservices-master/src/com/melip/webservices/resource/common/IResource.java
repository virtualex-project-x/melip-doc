package com.melip.webservices.resource.common;

/**
 * リソースの基底インタフェースです。
 */
public interface IResource {

}
